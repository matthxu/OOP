﻿// [OOP] Task 2.2 | Matthew Xu

class Program
{
    static void Main() {
        //  please specify the parameter to be 1XX, where XX is the last two digits of your student ID
        Shape myShape = new Shape(175);
        myShape.Draw();
        myShape.ComputePerimeter();
    }
}