﻿namespace SwinAdventure
{
    public class Item : GameObject
    {
        //constructor
        public Item(List<string> identifiers, string name, string description) : base(identifiers, name, description) { }
    }

}