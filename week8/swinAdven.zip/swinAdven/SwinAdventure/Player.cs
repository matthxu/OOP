namespace SwinAdventure
{
    public class Player : GameObject
    {
        // field
        private Inventory _inventory;
        private string _longDescription = "James is an explorer. He likes to explore. He loves exploring. He has a silver hat and a torch in his inventory. When he is exploring, James is happy. James can often be found exploring. James is a capable explorer. James is known as the explorer. James, the explorer. He is currently exploring. His one hobby is exploring. He works as an explorer. James is confused... James is hungry...James wants to explore more...";

        // property
        public Inventory Inventory
        {
            get { return _inventory; }
        }

        public string LongDescription
        {
            get { return _longDescription; }
        }
        // constructor
        // ? why do we set another name and desc for player class when it inherits same fields from parent gameobject class?
        // because we feed name and desc to the parent class from the player class
        public Player(string name, string desc) : base(new List<string> { "me", "inventory" }, name, desc)
        {
            _inventory = new Inventory(); // inventory initialised as empty with overloaded inventory constructor
        }

        // methods
        public GameObject Locate(string id)
        {
            if (AreYou(id))
            {
                return this;
            }
            else
            {
                return Inventory.Fetch(id);
            }

        }

        public override string FullDescription
        {
            get
            {
                return $"You are {Name} {base.FullDescription}\n" + "You are carrying:\n" + Inventory.ItemList;
            }
        }

        public override void SaveTo(StreamWriter writer)
        {
            base.SaveTo(writer);
            writer.WriteLine(_inventory.ItemList);
            writer.WriteLine(LongDescription);
        }

        public override void LoadFrom(StreamReader reader)
        {
            base.LoadFrom(reader);
            string ItemDescriptionList = reader.ReadLine();
            string LongPlayerDesc = reader.ReadLine();

            Console.WriteLine("Player Information");
            Console.WriteLine(Name);
            Console.WriteLine(ShortDescription);
            Console.WriteLine(ItemDescriptionList);
            Console.WriteLine(LongPlayerDesc);
        }
    }
}